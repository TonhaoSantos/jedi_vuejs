'strict'
/*
import Vue from 'vue'

import PluginExemplo from 'plugin-exemplo'

Vue.use(BootstrapVue)
*/
