export default {
  'MUTATION_NOME' (state, payload) {
    state.stateNome = payload
  }
}
