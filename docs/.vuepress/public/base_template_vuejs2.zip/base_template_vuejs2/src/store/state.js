export default {
  stateName: ''
}
