export default {
  changeUserType (context, payload) {
    context.commit('CHANGE_USER_TYPE', payload)
  }
}
