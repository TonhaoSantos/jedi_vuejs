export default {
  'CHANGE_LOGGED' (state, payload) {
    state.logged = payload
  }
}
