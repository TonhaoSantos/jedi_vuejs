export default {
  'CHANGE_USER_TYPE' (state, payload) {
    state.userType = payload
  }
}
