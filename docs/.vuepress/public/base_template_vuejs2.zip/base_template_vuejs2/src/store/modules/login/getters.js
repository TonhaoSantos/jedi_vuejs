export default {
  'logged' (state) {
    return state.logged
  }
}
