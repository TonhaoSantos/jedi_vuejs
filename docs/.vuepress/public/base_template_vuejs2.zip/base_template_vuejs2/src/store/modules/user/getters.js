export default {
  'userType' (state) {
    return state.userType
  }
}
