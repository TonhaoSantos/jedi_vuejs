export default {
  logged: false
}
