export default {
  changeErrors (context, payload) {
    context.commit('CHANGE_ERRORS', payload)
  }
}
