export default {
  'CHANGE_ERRORS' (state, payload) {
    state.errors = payload
  }
}
