export default {
  'errorsList' (state) {
    return state.errors
  }
}
