export default {
  userType: ''
}
