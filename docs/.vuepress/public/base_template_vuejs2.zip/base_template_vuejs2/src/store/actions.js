export default {
  acaoMutation (context, payload) {
    context.commit('MUTATION_NOME', payload)
  }
}
