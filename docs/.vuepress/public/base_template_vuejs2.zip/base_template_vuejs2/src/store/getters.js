export default {
  'stateNome' (state) {
    return state.stateNome
  }
}
