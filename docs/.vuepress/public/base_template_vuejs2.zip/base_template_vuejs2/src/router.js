import Vue from 'vue'
import Router from 'vue-router'

// Website pages
const HomePage = () => import('@/views/HomePage')
const AboutPage = () => import('@/views/AboutPage')

const LoginPage = () => import('@/views/LoginPage')

// Errors Pages
const Error404Page = () => import('@/views/errors/Error404Page')

// Modules Pages
const SystemBodyPage = () => import('@/views/system/SystemBodyPage')
// Admim
const AdminDashboardPage = () => import('@/views/system/admin/DashboardPage')
// User
const UserDashboardPage = () => import('@/views/system/user/DashboardPage')

Vue.use(Router)

const scrollBehavior = function (to, from, savedPosition) {
  if (savedPosition) {
    return savedPosition
  } else {
    const position = {}

    if (to.hash) {
      position.selector = to.hash

      if (to.hash === '#anchor2') {
        position.offset = { y: 100 }
      }

      if (document.querySelector(to.hash)) {
        return position
      }

      return false
    }

    return new Promise(resolve => {
      if (to.matched.some(m => m.meta.scrollToTop)) {
        position.x = 0
        position.y = 0
      }

      this.app.$root.$once('triggerScroll', () => {
        resolve(position)
      })
    })
  }
}

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  linkActiveClass: 'router-link-active',
  linkExactActiveClass: 'router-link-exact-active',
  routes: [
    {
      path: '/login',
      name: 'LoginPage',
      component: LoginPage
    },
    {
      path: '/',
      name: 'HomePage',
      component: HomePage
    },
    {
      path: '/about',
      name: 'AboutPage',
      component: AboutPage
    },
    {
      path: '/404',
      name: 'Error404Page',
      component: Error404Page,
      props: false
    },
    {
      path: '/system',
      name: 'SystemBodyPage',
      component: SystemBodyPage,
      props: false,
      meta: {
        requiresAuth: true
      },
      children: [
        {
          path: 'dashboard',
          name: 'AdminDashboardPage',
          component: AdminDashboardPage,
          meta: {
            userAdmin: true
          }
        },
        {
          path: 'clients',
          name: 'UserDashboardPage',
          component: UserDashboardPage,
          meta: {
            userClient: true
          }
        }
      ]
    },
    {
      path: '*',
      redirect: '/404'
    }
  ],
  scrollBehavior
})
