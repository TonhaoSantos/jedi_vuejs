export const myMixins = {
  data () {
    return {
    }
  },
  computed: {
  },
  methods: {
    isReallyArray (value) {
      if (Array.isArray(value)) {
        return true
      } else {
        return false
      }
    },
    hasProperty (objSearch, valueSearch) {
      if (typeof (objSearch[valueSearch]) !== 'undefined') {
        return true
      } else {
        return false
      }
    },
    isReallyString (value) {
      if (typeof value === 'string') {
        return true
      } else {
        return false
      }
    },
    has (value, key) {
      if (value[key] !== key) {
        return true
      }
    },
    isReallyEmpty (value) {
      if (value === null) {
        return true
      }

      if (this.isReallyArray(value) || this.isReallyString(value)) {
        return value.length === 0
      }

      for (let key in value) {
        if (this.has(value, key)) {
          return false
        }
      }

      return true
    }
  },
  filters: {
    textUpperCase (string) {
      return string.toUpperCase()
    },
    textCapitalizeFirstLetter (string) {
      return string.charAt(0).toUpperCase() + string.slice(1)
    }
  },
  watch: {}
}
