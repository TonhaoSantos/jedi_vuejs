<template>
  <div id="nav">
    <router-link :to="{ name: 'HomePage' }">Home</router-link> |
    <router-link :to="{ name: 'AboutPage' }">About</router-link> |

    <div v-if="!logged">
    <router-link :to="{ name: 'LoginPage' }">Login</router-link> |
    </div>

    <div v-else>
      <div v-if="userType === 'admin'">
        <router-link :to="{ name: 'AdminDashboardPage' }">Admin Dashboard</router-link> |
      </div>
      <div v-else-if="userType === 'client'">
        <router-link :to="{ name: 'UserDashboardPage' }">User Dashboard</router-link> |
      </div>

      <button  @click.prevent="logoutEvent" >Logout</button> |
    </div>

    <select v-model="$i18n.locale">
      <option v-for="(lang, i) in langs" :key="`Lang${i}`" :value="lang">{{ lang }}</option>
    </select>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'

export default {
  name: 'TheNavbar',
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {
      langs: ['pt-BR', 'en']
    }
  },
  computed: {
    ...mapGetters('ModuleLogin', [
      'logged'
    ]),
    ...mapGetters('ModuleUser', [
      'userType'
    ])
  },
  methods: {
    ...mapActions('ModuleLogin', [
      'changeLogged'
    ]),
    ...mapActions('ModuleUser', [
      'changeUserType'
    ]),
    logoutEvent () {
      localStorage.removeItem('system_user_type')
      localStorage.removeItem('system_token')

      this.changeLogged(false)
      this.changeUserType('')

      this.$router.push({ name: 'LoginPage' })
    }
  },
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
#nav div {
  display: inline-block;
}
</style>
