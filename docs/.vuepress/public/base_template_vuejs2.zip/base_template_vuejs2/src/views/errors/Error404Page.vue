<template>
  <div>
    <h1>Error 404 - Page not found</h1>
  </div>
</template>

<script>
export default {
  name: 'Error404Page',
  metaInfo: {
    title: '404 Page'
  },
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {}
  },
  computed: {},
  methods: {},
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
