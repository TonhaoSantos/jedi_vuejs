<template>
  <div class="dashboard-user">
    <p>Dashboard User Page View</p>
  </div>
</template>

<script>
export default {
  name: 'UserDashboardPage',
  metaInfo: {
    title: 'System User Page'
  },
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {}
  },
  components: {},
  computed: {},
  methods: {},
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
