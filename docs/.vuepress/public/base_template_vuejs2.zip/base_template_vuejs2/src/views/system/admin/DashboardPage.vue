<template>
  <div class="dashboard-admin">
    <p>Dashboard Admin Page View</p>
  </div>
</template>

<script>
export default {
  name: 'AdminDashboardPage',
  metaInfo: {
    title: 'System Admin Page'
  },
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {}
  },
  components: {},
  computed: {},
  methods: {},
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
