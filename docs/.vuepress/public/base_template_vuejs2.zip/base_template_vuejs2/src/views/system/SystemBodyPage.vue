<template>
  <div class="syetem-body-page">
    <h1>System Body Page View</h1>

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'SystemBodyPage',
  metaInfo: {
    title: 'System Body Page'
  },
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {}
  },
  components: {},
  computed: {},
  methods: {},
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
