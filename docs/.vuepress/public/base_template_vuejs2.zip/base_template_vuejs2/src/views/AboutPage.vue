<template>
  <div class="about">
    <h1>About Page View</h1>
  </div>
</template>

<script>
export default {
  name: 'AboutPage',
  metaInfo: {
    title: 'About Page'
  },
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {}
  },
  components: {},
  computed: {},
  methods: {},
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
