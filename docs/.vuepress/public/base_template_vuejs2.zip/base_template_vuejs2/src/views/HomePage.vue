<template>
  <div class="home">
    <h1>Home Page View</h1>

    <ul>
      <li v-for="(item, index) in starWars" :key="index">
        {{ item.name }} - {{ item.birth_year }} - {{ item.gender }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'HomePage',
  metaInfo: {
    title: 'HomePage'
  },
  beforeCreate () {},
  created () {
    this.getStarWars()
  },
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {
      starWars: []
    }
  },
  components: {},
  computed: {},
  methods: {
    getStarWars () {
      axios.get('https://swapi.co/api/people/')
        .then(response => {
          // console.log(response.data.results)
          this.starWars = response.data.results
        })
        .catch(e => {
          // console.log(e)
        })
    }
  },
  filters: {},
  watch: {}
}
</script>

<style scoped lang="scss">
</style>
