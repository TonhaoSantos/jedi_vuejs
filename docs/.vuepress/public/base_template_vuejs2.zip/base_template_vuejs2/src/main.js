import Vue from 'vue'
import App from '@/App.vue'
import router from '@/router'
import store from '@/store'
import VueMeta from 'vue-meta'
import '@/registerServiceWorker'
import { myMixins } from '@/mixins'

// Plugins
import i18n from './i18n'
import '@/plugins/pluginExemplo'

Vue.mixin(myMixins)

Vue.use(VueMeta)

Vue.config.productionTip = false

// Proteção das rotas (Auth)
router.beforeEach((to, from, next) => {
  // Obtendo usuadio/token salvo localmente
  const tokenLocalStorage = localStorage.getItem('system_token')
  const userTypeLocalStorage = localStorage.getItem('system_user_type')

  // Meta da rota
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth)
  const requiresUserAdmin = to.matched.some(record => record.meta.userAdmin)
  const requiresUserClient = to.matched.some(record => record.meta.userClient)

  if (requiresAuth && !tokenLocalStorage) {
    next({ name: 'LoginPage' })
  } else if (requiresAuth && tokenLocalStorage) {
    if (requiresUserAdmin && userTypeLocalStorage === 'admin') {
      next()
    } else if (requiresUserClient && userTypeLocalStorage === 'client') {
      next()
    } else {
      next({ name: 'HomePage' })
    }
  } else if (tokenLocalStorage && to.path === '/login') {
    next({ name: 'HomePage' })
  } else {
    next()
  }
})

new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount('#app')
