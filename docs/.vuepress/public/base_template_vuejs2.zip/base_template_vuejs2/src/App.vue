<template>
  <div id="app">
    <TheNavbar />

    <button class="bt-updateWorker" v-if="updateExists" @click="refreshApp">
      New version available! Click to update
    </button>

    <p>Menagem do I18N {{ $t('message') }}</p>

    <router-view/>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'

const TheNavbar = () => import('@/components/layout/TheNavbar')

export default {
  name: 'App',
  metaInfo () {
    const locale = this.$i18n.locale
    return {
      title: 'Default Title',
      titleTemplate: chunk => (
        locale === 'en' ? `${chunk} | App Name'` : `${chunk} | Nome App`
      ),
      htmlAttrs: {
        lang: 'pt-BR'
      },
      meta: [
        { vmid: 'charset', name: 'charset', content: 'utf-8' },
        { vmid: 'viewport', name: 'viewport', content: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no' },
        { vmid: 'google-site-verification', name: 'google-site-verification', content: 'Codigo Google' },
        { vmid: 'robots', name: 'robots', content: 'index, follow' },
        { vmid: 'msvalidate.01', name: 'msvalidate.01', content: 'Codigo Bing' },
        { vmid: 'description', name: 'description', content: 'First PWA Vue.js App' },
        { vmid: 'keywords', name: 'keywords', content: 'Palavras Chaves' },
        { vmid: 'copyright', name: 'copyright', content: 'Nome Empresa/Site, Copyright (c) 2018' },
        { vmid: 'author', name: 'author', content: 'Nome' },
        { vmid: 'http-equiv', 'http-equiv': 'X-UA-Compatible', content: 'IE=edge,chrome=1' },
        // Facebook - OpenGraph Data
        { property: 'og:title', content: 'Titulo ← Meu Site' },
        { property: 'og:description', content: 'Descrição' },
        { property: 'og:url', content: 'url absoluta' },
        { property: 'og:site_name', content: 'Nome do Site' },
        { property: 'og:type', content: 'website' },
        { property: 'og:image', content: 'url absoluta' },
        { property: 'og:image:type', content: 'image/png' },
        { property: 'og:image:width', content: '1200' },
        { property: 'og:image:height', content: '630' },
        { property: 'og:locale', content: 'pt_BR' },
        { property: 'fb:app_id', content: 'APP ID gerado no facebook' },
        // Twitter card
        { name: 'twitter:card', content: 'summary' },
        { name: 'twitter:site', content: 'url absoluta' },
        { name: 'twitter:title', content: 'Titulo ← Meu Site' },
        { name: 'twitter:description', content: 'Descrição' },
        { name: 'twitter:creator', content: '@algumacoisa' },
        { name: 'twitter:image:src', content: 'url absoluta da conta do twitter' },
        // Google
        { itemprop: 'name', content: 'Titulo ← Meu Site' },
        { itemprop: 'description', content: 'Descrição' },
        { itemprop: 'image', content: 'url absoluta' }
      ],
      link: [
        { rel: 'manifest', href: '/manifest.json' },
        { rel: 'canonical', href: 'https://localhost:3000' },
        { rel: 'text/plain', href: '/humans.txt' }
      ]
    }
  },
  beforeCreate () {},
  created () {
    document.addEventListener('swUpdated', this.showRefreshUI, { once: true })

    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (this.refreshing) return

      this.refreshing = true
      window.location.reload()
    })
  },
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  beforeDestroy () {},
  destroyed () {},
  data () {
    return {
      langs: ['pt-BR', 'en'],
      refreshing: false,
      registration: null,
      updateExists: false
    }
  },
  components: {
    TheNavbar
  },
  computed: {
    ...mapGetters('ModuleLogin', [
      'logged'
    ])
  },
  methods: {
    ...mapActions('ModuleLogin', [
      'changeLogged'
    ]),
    logoutEvent () {
      localStorage.removeItem('system_user_type')
      localStorage.removeItem('system_token')

      this.changeLogged(false)

      this.$router.push({ name: 'LoginPage' })
    },
    showRefreshUI (e) {
      this.registration = e.detail
      this.updateExists = true
    },
    refreshApp () {
      this.updateExists = false

      if (!this.registration || !this.registration.waiting) {
        return
      }

      this.registration.waiting.postMessage('skipWaiting')
    }
  },
  filters: {},
  watch: {}
}
</script>

<style lang="scss">
.bt-updateWorker {
  a {
    background-color: tomato;
    padding: 10px;
    color: #fff;
    font-weight: 800;
  }
}
</style>
