![Logo of the project](./images/logo.sample.png)
# frontend_vuejs_vuecli3 [![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](https://bitbucket.org/tonhaosantos/frontend_vuejs_vuecli3/src/master/LICENSE)

> Project generated with **[Vue Cli 3](https://cli.vuejs.org/ "Vue Cli 3 Website")** and **[Vue.js 2x](https://vuejs.org/ "Vue.js Website")**, uses the design pattern described in this [documentação](https://jedicatvuejs.netlify.com/guide/intalacao.html#estrutura-projeto).

## Developing
### Built With
It was used in the development of this application:
> All specified versions are minimal.
> To learn how to use Vuex, Vue Router, SASS, Additional Plugins, Mixins and modules of this project use this [documentação](https://jedicatvuejs.netlify.com/guide/configuracao.html).
- [Express Js](https://expressjs.com/pt-br/) - v4.16.4
- [Vue.js](https://vuejs.org/) - v2.6.10
- [Vue Cli](https://cli.vuejs.org/) - v3.5.1
- [Vue I18N](https://github.com/kazupon/vue-i18n) - v3.4.23
- [Vue Router](https://router.vuejs.org/) - v3.0.3
- [Vue PWA](https://router.vuejs.org/) - v3.0.3
- [Vuex](https://vuex.vuejs.org/) - v3.0.1
- [Vuex Persistedstate](https://github.com/robinvdvleuten/vuex-persistedstate) - v3.0.1
- [Vue cli-plugin-babel](https://www.npmjs.com/package/@vue/cli-plugin-babel) - v3.6.0
- [Vue cli-plugin-e2e-nightwatch](https://www.npmjs.com/package/@vue/cli-plugin-e2e-nightwatch) - v3.6.0
- [Vue cli-plugin-eslint](https://www.npmjs.com/package/@vue/cli-plugin-eslint) - v3.6.0
- [Vue cli-plugin-pwa](https://www.npmjs.com/package/@vue/cli-plugin-pwa) - v3.6.0
- [Vue cli-plugin-unit-jest](https://www.npmjs.com/package/@vue/cli-plugin-unit-jest) - v3.6.0
- [vue cli-service](https://cli.vuejs.org/guide/cli-service.html) - v3.6.0
- [vue eslint-config-standard](https://www.npmjs.com/package/@vue/eslint-config-standard) - v4.0.0
- [vue test-utils](https://vue-test-utils.vuejs.org/) - v1.0.0-beta.29
- [vue-cli-plugin-i18n](https://github.com/kazupon/vue-cli-plugin-i18n) - v0.6.0
- [vue-template-compiler](https://www.npmjs.com/package/vue-template-compiler) - v2.5.21
- [Node.js](https://nodejs.org/en/) - v11.4.0
- [Yarn](https://yarnpkg.com) - v1.12.3
- [SASS/SCSS](https://sass-lang.com/) - v3.4.23
- [Register Service Worker](https://github.com/yyx990803/register-service-worker#readme) - v1.6.2
- [Core Js](https://github.com/zloirock/core-js/tree/v2) - v2.6.5
- [Babel](https://babeljs.io/)
    - Babel Core - v7.0.0-bridge.0
    - Babel Eslint - v10.0.1
    - Babel Jest - v23.6.0
- [eslint](https://eslint.org/) - v5.16.0
- [eslint-plugin-vue](https://github.com/vuejs/eslint-plugin-vue) - v5.0.0
- [node-sass](https://github.com/sass/node-sass) - v4.9.0
- [sass-loader](https://github.com/webpack-contrib/sass-loader) - v7.1.0



### Important Explanation
- **[I18N](https://github.com/kazupon/vue-cli-plugin-i18n)**, by default it already provides settings for two languages **pt-BR** and **en**. To provide for more languages just create the files in the directory __src/locales__. Remember that you must have the same keys on all files that have a perfect working order. This plugin is configured with a language __default__ and one of __fallback__ _"error"_,  to change both go in the file __vue.config.js__ located in the root of the project and change the fields __locale__ _"represents the default"_ and __fallbackLocale__ _"represents the fallback"_ to those desired. When changing __default__ and __fallbackLocale__ languages, you must change the [Environment Variable](#Variavel-de-ambiente) in the keys __VUE_APP_I18N_LOCALE__ _"for default and"_ and __VUE_APP_I18N_FALLBACK_LOCALE__ "for the fallback".
- [vuex-persistedstate](https://github.com/robinvdvleuten/vuex-persistedstate), persists store data by refreshing the page in **LocalStorage**, allowing not to delete **Store** data by opening another tab in the browser or even refreshing the page. It is of great value to erase the data saved in **LocalStorage** with the name ** vuex ** when logging out or even closing the system tabs with the **beforeDestroy** or **destroyed** hook.


### Variavel de ambiente
For the project to work properly and has better security work with two environment variables files that are being ignored by Git through **.gitignore** file.

Create the files at the root of your project with the names:
- **env.development**: Used by _Vue.js_ when you are developing your project.
- **env.production**: Using by _Vue.js_ when generating project _Build_.

With the following structure and the appropriate values for your project:

```js
{
  VUE_APP_KEY_NAME=value you want
}
```

It is mandatory to have at least these keys and values to work perfectly:
```js
{
  VUE_APP_I18N_LOCALE=pt-BR
  VUE_APP_I18N_FALLBACK_LOCALE=en
}
```

### Paginas
By default the project already comes with the following pages:
- Login: You do not have to be logged in to access, but log in is not possible to access this page. When running a login event you need to provide a token to be saved in **LocalStorage** with the name **system_token**. You also need to store the user type in the **LocalStorage** with the name **system_user_type** with one of the following values __"admin"__ or __"client"__ depending on the type available for the user to access the respective pages to the "System" informed below..
- System
  - Dashboard Admin: You must be logged in to access and be administrator type.
  - Dashboard User: You must be logged in to access and be a user type.
- Home: You do not have to be logged in to access.
- About: You do not have to be logged in to access.
- Erro 404: You do not have to be logged in to access.


## Instalação e Utilização
### Prerequisites and Installing
- Terminal (Command used in Terminal and not at Powershell)
- Node.js
- Yarn
- Vue.js

### **Project setup**
To run this project you must first install the dependencies. In the root directory type:
```
yarn install
```

#### Compiles and hot-reloads for development
```
yarn run serve
```

#### Compiles and minifies for production
```
yarn run build
```

#### I18N Reports
```
yarn run i18n:report
```

#### Lints and fixes files
```
yarn run lint
```

#### Run your end-to-end tests
```
yarn run test:e2e
```

#### Run your unit tests
```
yarn run test:unit
```

#### Run your verbose unit tests
```
yarn run test:unit_verbose
```

To test the application in the browser click here [```http://localhost:8080```](http://localhost:8080).

### **Production**
For production you need to do some tricks to run the **Vue Route history mode** on some deploy services.

## [netlify](http://netlify.com)
To use in **netlify** you will need to create within the **public** directory a file with the name ***_redirects*** and the following content:
```js
/*    /index.html   200
```
Go to **Settings > Build & Deploy** and in the **Build settings** session in iiii report:

- Build command: **yarn build**
- Publish directory: **dist**

## Docker
With the docker can be done using the following Dockerfile:

```js
FROM node:10.15.0-alpine

WORKDIR /home/node/app

COPY server.js ./
COPY dist/ ./dist

RUN yarn add express

USER node

EXPOSE 5000

CMD node server.js
```

## Others
> You must have **node js** and **yarn** installed on vps

For some services that offer **VPS** and **related** like __Digital Ocean__, __AWS__, __Azure__, __Heroku__, ... you can serve as an **[Express.js]()**. To do this I already made available a **server.js** file by default, just run the command:

```js
yarn install

yarn build
```

And then run the command to execute **Express.js**:

```js
node ./server.js
```



### **Versioning**
1.0.0

### **Licensing**
MIT
Copyright (c) 2019 Tonhão Santos.
